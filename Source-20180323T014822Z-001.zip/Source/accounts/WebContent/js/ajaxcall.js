function getReqXML(singleInput)
{
	  var xml = "<texts>";
   		xml = xml + "<text>" + singleInput + "<\/text>";
  		xml = xml + "<\/texts>";
 return xml;
}
		
function ajaxSubmit(xmlInput, method, targetURL, asyn)
{
	makePostRequest(xmlInput, method, targetURL, asyn);
}
		
function createRequestObject() {
    var tmpXmlHttpObject;
    
    if (window.XMLHttpRequest) { 
        // Mozilla, Safari would use this method ...
        tmpXmlHttpObject = new XMLHttpRequest();
	
    } else if (window.ActiveXObject) { 
        // IE would use this method ...
        tmpXmlHttpObject = new ActiveXObject("Microsoft.XMLHTTP");
    }
    
    return tmpXmlHttpObject;
}

var http = createRequestObject();

function makePostRequest(xmlInput, method, targetURL, asyn) {
	var response = "";
    http.open(method, targetURL, asyn);

    //assign a handler for the response
    http.onreadystatechange = function(){
	   //check if the response has been received from the server
    if(http.readyState == 4){
		if (http.status == 200) {
        //read and assign the response from the server
        response = http.responseXML.documentElement;
        
        //self-define function
        processResponse(response);
			
        //If the server returned an error message like a 404 error, that message would be shown within the div tag!!. 
        //So it may be worth doing some basic error before setting the contents of the <div>
        }
        else {
        alert("Problem with server response:\n " + http.statusText);
        response = "";
      	}
      }
	};
	
    //actually send the request to the server
    if(xmlInput == null){
		xmlInput = "";
	}
    http.setRequestHeader("Content-Type", "text/xml");
    http.send(xmlInput);

}

