function PopWindow(url, pageName, scrollable, theWidth, theHeight)
{
	var width=theWidth;
	var height=theHeight;
	var centerX=(screen.width-width)/2; //pop up center screen
	var centerY=(screen.height-height)/2;
	if (scrollable == 1)
		window.open(url, pageName, "toolbar=no, status=yes, scrollbars=yes, menubar=no, resizable=no, width=" + width + ",height="+height+ ",top="+centerY+",screenY=" + centerY + ",left=" + centerX + ",screenX=" + centerX);
	else
		window.open(url, pageName, "toolbar=no, status=no, scrollbars=no, menubar=no, resizable=no, width=" + width + ",height="+height+ ",top="+centerY+",screenY=" + centerY + ",left=" + centerX + ",screenX=" + centerX);
	//return false;
}

String.prototype.trim = function() {
	return this.replace(/^\s+|\s+$/g,"");
};
String.prototype.ltrim = function() {
	return this.replace(/^\s+/,"");
};
String.prototype.rtrim = function() {
	return this.replace(/\s+$/,"");
};

//only allow input 0-9
function checkField(object) {
if (event.keyCode < 48 || event.keyCode > 57) {
return false;
} // end if
return true;
} 