// vertical positioning in the viewport
// obtained from http://www.learningjquery.com/2007/12/questions-and-answers-from-the-list
// modified by kwx on 20080613

(function($){
	$.fn.vhCenter = function(options) {
		var pos = {
			sTop : function() {
				return window.pageYOffset 
				  || document.documentElement && document.documentElement.scrollTop 
				  || document.body.scrollTop;
			},
			wHeight : function() {
				return window.innerHeight 
				  || document.documentElement && document.documentElement.clientHeight 
				  || document.body.clientHeight;
			},
			sLeft : function() {
				return window.pageXOffset 
				  || document.documentElement && document.documentElement.scrollLeft 
				  || document.body.scrollLeft;
			},
			wWidth : function() {
				return window.innerWidth 
				  || document.documentElement && document.documentElement.clientWidth 
				  || document.body.clientWidth;
			}
		};
		return this.each(function(index) {
			if (index == 0) {
				var $this = $(this);

				var elHeight = $this.height();
				var elTop = Math.max(pos.sTop() + (pos.wHeight() / 2) - (elHeight / 2), 0);

				var elWidth = $this.width();
				var elLeft = pos.sLeft() + (pos.wWidth() / 2) - (elWidth / 2);


				$this.css({
					position: 'absolute',
					marginTop: '0',
					top: elTop,
					left: elLeft
				});
			}
		});
	};
})(jQuery);
