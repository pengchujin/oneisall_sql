$(document).ready(function(){
	
	$("#container").vhCenter();
	$(window).resize(
		function(){	$("#container").vhCenter();}
	);
	
	$.ifixpng('images/pixel.gif');
	$("div.forgot a, #terms a, #logo").ifixpng();

	/*$("#flashObj").flash({
		swf: 'swf/loginPage.swf',
		width: 890,
		height: 630,
		wmode: "transparent",
		allowScriptAccess: "sameDomain",
		allowNetworking: "internal"
	});*/
	
	
});