package com.mtrchome.security;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.jasypt.util.text.BasicTextEncryptor;
import org.springframework.security.AuthenticationException;
import org.springframework.security.ui.webapp.AuthenticationProcessingFilter;
import org.springframework.security.ui.webapp.AuthenticationProcessingFilterEntryPoint;
/**
 * This class is the custom authentication entry point of the authentication processing filter
 * @author Alvin Chan
 */
public class CustomAuthenticationEntryPoint extends AuthenticationProcessingFilterEntryPoint {

	/**
	 * For logging information
	 */
private final org.apache.log4j.Logger log = Logger.getLogger(this.getClass());

/**
 * To get the log
 * @return org.apache.log4j.Logger
 */
public org.apache.log4j.Logger getLog() {
	return log;
}

@Override
public void commence(ServletRequest request, ServletResponse response, AuthenticationException authException) throws IOException, ServletException {

	log.debug("commence started.");
	 super.commence(request, response, authException);

}

}