package com.mtrchome.security;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.jasypt.util.password.StrongPasswordEncryptor;
import org.jasypt.util.text.BasicTextEncryptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.Authentication;
import org.springframework.security.AuthenticationException;
import org.springframework.security.ui.webapp.AuthenticationProcessingFilter;

import com.mtrchome.accmgm.dao.MtrchomeAuditDAO;
import com.mtrchome.accmgm.dao.MtrchomeConfigDAO;
import com.mtrchome.accmgm.model.MtrchomeAudit;
import com.mtrchome.accmgm.model.MtrchomeUser;
import com.mtrchome.accmgm.model.enums.AuditActionType;
import com.mtrchome.accmgm.model.enums.UserLanguage;
import com.mtrchome.accmgm.model.enums.UserStatus;
import com.mtrchome.accmgm.model.enums.UserType;
import com.mtrchome.accmgm.service.EstateService;
import com.mtrchome.accmgm.service.UserService;
import com.mtrchome.accmgm.util.Constants;
import com.mtrchome.accmgm.util.Helper;
import com.mtrchome.accmgm.util.MyProperties;
import com.mtrchome.booking.domain.ClubHouse;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;

/**
 * A custom authentication filter for the Authentication Processing Filter, this class mainly handle the logic after user is login successfully
 * @author Alvin Chan
 */
public class CustomAuthenticationFilter extends AuthenticationProcessingFilter {

	/**
	 * UserService contains methods for data maintenance of users
	 */
	@Autowired
	private UserService userService = null;
	/**
	 * MtrchomeAuditDAO contains method for audit process
	 */
	@Autowired
	private MtrchomeAuditDAO auditDAO = null;
	
	/**
	 * The mtrchome config DAO
	 */
	@Autowired
	private MtrchomeConfigDAO configDAO = null;
	/**
	 * EstateService contains methods for data maintenance of estate
	 */
	@Autowired
	private EstateService estateService = null;
	/**
	 * For logging information
	 */
	private final org.apache.log4j.Logger log = Logger.getLogger(this.getClass());
	
	//added expired password - 20091118
	/**
	 * The flag indicate if the user password is expired
	 */
	private boolean expiredPassword = true;
	/**
	 * The flag indicate if there is redirect
	 */
	boolean haveRedirect = false;

	/**
	 * To get the field expiredPassword
	 * @return the expiredPassword
	 */
	public boolean isExpiredPassword() {
		return expiredPassword;
	}

	/**
	 * To set the field expiredPassword
	 * @param expiredPassword the expiredPassword to set
	 */
	public void setExpiredPassword(boolean expiredPassword) {
		this.expiredPassword = expiredPassword;
	}

	/**
	 * To get the field haveRedirect
	 * @return the haveRedirect
	 */
	public boolean isHaveRedirect() {
		return haveRedirect;
	}

	/**
	 * To set the field haveRedirect
	 * @param haveRedirect the haveRedirect to set
	 */
	public void setHaveRedirect(boolean haveRedirect) {
		this.haveRedirect = haveRedirect;
	}

	//End - added expired password - 20091118

	/**
	 * To get the field userService
	 * @return the userService
	 */
	public UserService getUserService() {
		return userService;
	}

	/**
	 * To set the field userService
	 * @param userService the userService to set
	 */
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	/**
	 * To get the field auditDAO
	 * @return the auditDAO
	 */
	public MtrchomeAuditDAO getAuditDAO() {
		return auditDAO;
	}

	/**
	 * To set the field auditDAO
	 * @param auditDAO the auditDAO to set
	 */
	public void setAuditDAO(MtrchomeAuditDAO auditDAO) {
		this.auditDAO = auditDAO;
	}

	/**
	 * If the authentication is successful, system need to set the followings: <br/>
	 * - create a session cookie (for the SSO in booking system) <br/>
	 * - logging <br/>
	 * - set the boolean flag of "isForgotPassword" to false <br/>
	 * - check the estate has club house and set cookie
	 */
	@Override
	protected void onSuccessfulAuthentication(HttpServletRequest request,
			HttpServletResponse response, Authentication authResult)
			throws IOException {
		super.onSuccessfulAuthentication(request, response, authResult);
		
		haveRedirect = false;
		
		CustomRememberMeService remService = new CustomRememberMeService();
		remService.createToken(request, response, authResult);
		
		SecurityUser suser = (SecurityUser) request.getSession().getAttribute(Constants.USER_SESSION_NAME);
		MtrchomeUser user = suser.getDBUser();
		Long estId = Long.valueOf("0");
		int usertype = Integer.valueOf(String.valueOf(user.getUserTypeId()));
		if (usertype != UserType.Super_Admin.type()){
			user.setMtrchomeEstate(userService.getUserEstate(user.getLoginName()));
			estId = user.getMtrchomeEstate().getEstateId();
		}
		
		if (user.getIsForgotPassword()){
			try{
				user.setIsForgotPassword(false);
				MtrchomeUser returnuser = userService.saveUser(user);
				suser.setDBUser(returnuser);
				request.getSession().setAttribute(Constants.USER_SESSION_NAME, suser);
			} catch (Exception e) {
				log.error("Error in setting isForgotPassword attribute in DB " + e.getMessage());
			}	
		}
		
		//check estate has clubhouse to show link to booking
		ClubHouse clubHouse = null;
		if(user.getMtrchomeEstate()!=null){
			clubHouse = estateService.getClubHouseByEstateId(user.getMtrchomeEstate().getEstateId());
		}
		
    	//System.out.println("clubHouse = "+clubHouse);
    	if(clubHouse != null){
    		request.getSession().setAttribute(Constants.HAS_CLUB_HOUSE, true);
    	}
    	else{
    		request.getSession().setAttribute(Constants.HAS_CLUB_HOUSE, false);
    	}
    	
    	//20111101 - For Admin role, login support popup control
		if (usertype == UserType.Estate_Manager.type() || usertype == UserType.Estate_Operator.type() || usertype == UserType.Contractor.type()){
			int langId = Helper.getCurrentLanguageId();
			//int supportPopupControlFlag = Integer.parseInt(MyProperties.getValue("session.supportPopupControl.flag"));
			int supportPopupControlFlag = Integer.parseInt(configDAO.findValueByConfigName(Constants.CONFIG_SUPPORT_POPUP_CONTROL_FLAG));
			String supportPopupControlMessage = null;
			String supportPopupControlURL = configDAO.findValueByConfigName(Constants.CONFIG_SUPPORT_POPUP_CONTROL_URL);
			
			if(langId == UserLanguage.English.language()){
				supportPopupControlMessage = configDAO.findValueByConfigName(Constants.CONFIG_SUPPORT_POPUP_CONTROL_MESSAGE_EN);
			}else{
				supportPopupControlMessage = configDAO.findValueByConfigName(Constants.CONFIG_SUPPORT_POPUP_CONTROL_MESSAGE_TW);
			}
			
    		request.getSession().setAttribute(Constants.SUPPORT_POPUP_CONTROL, supportPopupControlFlag);
    		request.getSession().setAttribute(Constants.SUPPORT_POPUP_CONTROL_MESSAGE, supportPopupControlMessage);
    		request.getSession().setAttribute(Constants.SUPPORT_POPUP_CONTROL_URL, supportPopupControlURL);
		}
    	//End - 20111101 - For Admin role, login support popup control
    	
		try{
			MtrchomeAudit audit = new MtrchomeAudit(Constants.AUDIT_APPLICATION_CODE, AuditActionType.User_Login.type(), new Date(), user.getUserId(), "User login.", estId, user.getUserId());
			auditDAO.save(audit);
		}catch(Exception ex){
			log.error("Error in writing audit log");
		}
	}
	
	/**
	 * Program logic / Validation: <br/>
	 * Page redirect after the user is login successfully, the system will check: <br/>
	 * - Check if the user account is locked,  <br/>
	 * 		- if locked, check the locked date and time. If locked after 10 mins, reset logonFailuresCount. If not, redirect to logout page <br/>
	 * 		- if not locked, reset logonFailuresCount.  <br/>
	 * - For administrator, check if the user password expired, <br/>
	 * 		- if expired, redirect to force change password page and set "changePWD" session <br/>
	 * - If user is reset password, redirect to change password page
	 */
	@Override
	protected void sendRedirect(HttpServletRequest request, HttpServletResponse response, String url) throws IOException{
		SecurityUser suser = (SecurityUser) request.getSession().getAttribute(Constants.USER_SESSION_NAME);
		if (suser != null){
			MtrchomeUser user = suser.getDBUser();
			MtrchomeUser returnuser = user;

			Calendar curDate = Calendar.getInstance();
			Long curDateMillis = curDate.getTimeInMillis();
			
			int usertype = Integer.valueOf(String.valueOf(user.getUserTypeId()));

			//Enforce Admin to change password in the first login - 20100913
			if (usertype == UserType.Estate_Manager.type() || usertype == UserType.Estate_Operator.type() || usertype == UserType.Contractor.type()){
				if(!haveRedirect){
					if(user.getLastLoginDate()==null){
						response.sendRedirect("forceChangePassword");
						request.getSession().setAttribute("changePWD", "true");
						haveRedirect = true;
					}
					
					log.info("user - "+user.getLoginName()+" redirect to changePassword page for admin first login");
				}
			}
			//End - Enforce Admin to change password in the first login - 20100913
			
			if (usertype == UserType.Super_Admin.type() || usertype == UserType.Estate_Manager.type() || usertype == UserType.Estate_Operator.type() || 
					usertype == UserType.Owner.type() || usertype == UserType.Tenant.type() || usertype == UserType.Limited_User.type()
					//201002 Phase 2 new role
					|| usertype == UserType.Contractor.type()){
				if(!haveRedirect){
					//Check whether the account is locked and should it be released - 20091124
					String lockedTimeStr = MyProperties.getValue("account.lockTime");
					Long lockedTime = Long.parseLong(lockedTimeStr);
					
					Date lockedDate = new Date();
					if(user.getLockedDate() != null){
						lockedDate = user.getLockedDate();
					}
					Long lockedDateMillis = lockedDate.getTime();

					boolean locked = false;
					if(user.getIsLocked() != null){
						locked = user.getIsLocked();
					}
					
					if(locked == false){
						user.setIsLocked(false);
						user.setLogonFailuresCount(Long.parseLong("0"));
						returnuser = userService.update(user);
						//request.getSession().setAttribute(Constants.USER_SESSION_NAME, returnuser);
					}
					else if(locked == true){
						if((curDateMillis - lockedDateMillis) >= lockedTime){
							user.setIsLocked(false);
							user.setLogonFailuresCount(Long.parseLong("0"));
							returnuser = userService.update(user);
							//request.getSession().setAttribute(Constants.USER_SESSION_NAME, returnuser);
						}
						else{	
							response.sendRedirect("logoutAccounts?locked=true");
							//response.sendRedirect("logout");
							haveRedirect = true;
							
							request.getSession().setAttribute("locked", "true");
							
							log.info("user - "+user.getLoginName()+" redirect to logout page, lockedDate = "+lockedDate);
						}
					} 
					//End - Check whether the account is locked and should it be released - 20091124
					
					//Set last login date - 20100910
					if(!haveRedirect){
						if(user.getLastLoginDate()==null){
							user.setLastLoginDate(new Date());
						}
						user.setCurrentLoginDate(new Date());
						returnuser = userService.update(user);
					}
					//End - Set last login date - 20100910
				}
			}

			if (usertype == UserType.Super_Admin.type() || usertype == UserType.Estate_Manager.type() || usertype == UserType.Estate_Operator.type()
					//201002 Phase 2 new role
					|| usertype == UserType.Contractor.type()){
				if(!haveRedirect){
					//Check if the last changed password is expired (default 180days) - 20091124
					String expireDayStr = MyProperties.getValue("password.expireDay");
					Long expireDay = Long.parseLong(expireDayStr);
					
					Date lastPasswordDate = new Date();
					if(user.getLastPasswordChanged() != null){
						lastPasswordDate = user.getLastPasswordChanged();
					}
					else{
						user.setLastPasswordChanged(lastPasswordDate);
						returnuser = userService.update(user);
						//request.getSession().setAttribute(Constants.USER_SESSION_NAME, returnuser);
					}
					Long lastPasswordDateMillis = lastPasswordDate.getTime();

					if ((curDateMillis - lastPasswordDateMillis) >= expireDay){	//180days 
					//if ((curDateMillis - lastPasswordDateMillis) >= 300000){	//5mins
						//response.sendRedirect("changePassword?changePWD=true");
						response.sendRedirect("forceChangePassword");
						request.getSession().setAttribute("changePWD", "true");
						haveRedirect = true;
						
						log.info("user - "+user.getLoginName()+" redirect to changePassword page, lastPasswordChanged = "+lastPasswordDate);
					}
					//End - Check if the last changed password is expired (default 180days) - 20091124
				}
			}

			if(!haveRedirect){
				if (user.getIsResetPassword()){
					response.sendRedirect("changePassword");
					haveRedirect = true;
				}
				else {
					String redirectURL = null;
					Cookie[] cookies = request.getCookies();
					if (cookies != null){
						for (int i=0; i<cookies.length; i++){
							Cookie currCookie = cookies[i];
							if (currCookie.getName().equals(Constants.LOGIN_REDIRECT_URL)){
								redirectURL = currCookie.getValue();
								break;
							}
						}
					}
					
					Cookie locationCookie = new Cookie(Constants.LOCATION, null);
					locationCookie.setPath("/");
		    		response.addCookie(locationCookie);
		    		
		    		log.info("Login redirectURL = "+redirectURL);
				//	String redirectURL = (String)request.getSession().getAttribute(Constants.LOGIN_REDIRECT_URL);
					if (redirectURL != null && !redirectURL.equals("")){
						response.sendRedirect("reloginRedirect");
						haveRedirect = true;
					}
				}
			}
			
			if(!haveRedirect)
				super.sendRedirect(request, response, url);
			
		}else{
			if(!haveRedirect)
				super.sendRedirect(request, response, url);
		}
	}

	/**
	 * Program logic / Validation:
	 * If the authentication is unsuccessful, system need to set the followings: <br/>
	 * - create a session cookie (for the SSO in booking system) <br/>
	 * - logging <br/>
	 * - increase logonFailuresCount by one, if logonFailuresCount > 5, lock the user account and set the locked date <br/>
	 * - check if non activate account, redirect to activation page
	 */
	@Override	
	protected void onUnsuccessfulAuthentication(HttpServletRequest request, 
			HttpServletResponse response, AuthenticationException failed) 
			throws IOException {
		super.onUnsuccessfulAuthentication(request, response, failed);
		
		haveRedirect = false;
			
		String loginName = request.getParameter("j_username");

		if(loginName != null){
			
			MtrchomeUser user = userService.findByLoginName(loginName, UserStatus.Activated.status());
			
			try{
				if(user!=null){
					
					MtrchomeUser returnuser = user;
					
					//Count login failure - 20091125
					int usertype = Integer.valueOf(String.valueOf(user.getUserTypeId()));
					if (usertype == UserType.Super_Admin.type() || usertype == UserType.Estate_Manager.type() || usertype == UserType.Estate_Operator.type() || 
							usertype == UserType.Owner.type() || usertype == UserType.Tenant.type() || usertype == UserType.Limited_User.type()
							//201002 Phase 2 new role
							|| usertype == UserType.Contractor.type()){
					
						int countFail = 0;
						
						if(user.getLogonFailuresCount() != null){
							countFail = Integer.valueOf(""+user.getLogonFailuresCount()).intValue();
						}
				    	countFail++;
				    	
				    	log.info("user - "+user.getLoginName()+" failed to login for "+ countFail +" times.");
				    	
						String maxFailLogin = MyProperties.getValue("account.failLoginCounter");
						int maxLoginFail = Integer.parseInt(maxFailLogin);
				    	
						Date lockedDate = new Date();
						if(user.getLockedDate() != null){
							lockedDate = user.getLockedDate();
						}
						boolean locked = false;
						if(user.getIsLocked() != null){
							locked = user.getIsLocked();
						}
				    	if(countFail >= maxLoginFail && locked==false){
				    		user.setIsLocked(true);
				    		user.setLockedDate(new Date());
				    		
				    		log.info("user - "+user.getLoginName()+" account locked date: "+ lockedDate);
				    	}
				    	user.setLogonFailuresCount(Long.parseLong(""+countFail));
				    	returnuser = userService.update(user);
				    	
					}
				}
				else{
					//Redirect to activation page for non-activated account - 20091125
					user = userService.findByLoginName(loginName, UserStatus.Non_Activate.status());
					if(user!=null && !haveRedirect){
						response.sendRedirect("activation.action");
						haveRedirect = true;
					}
				}
			}catch(Exception e){
				//e.printStackTrace();
				log.error("Error in adding login fail counter." + e.toString());
			}
			try{
				//MtrchomeAudit audit = new MtrchomeAudit(Constants.AUDIT_APPLICATION_CODE, AuditActionType.User_Login.type(), new Date(), user.getUserId(), "User login.", estId, user.getUserId());
				//auditDAO.save(audit);
			}catch(Exception ex){
				log.error("Error in writing audit log");
			}
		}
	}
}