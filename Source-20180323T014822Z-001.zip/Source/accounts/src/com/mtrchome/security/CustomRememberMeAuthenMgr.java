package com.mtrchome.security;
import org.apache.log4j.Logger;
import org.springframework.security.Authentication;
import org.springframework.security.AuthenticationException;
import org.springframework.security.AuthenticationManager;
import org.springframework.security.providers.AuthenticationProvider;
import org.springframework.security.providers.rememberme.RememberMeAuthenticationProvider;

/**
 * A custom authentication manager for the 'Remember Me' service
 * @author Alvin Chan
 */
public class CustomRememberMeAuthenMgr  implements AuthenticationManager{

	/**
	 * For logging information
	 */
	private final org.apache.log4j.Logger log = Logger.getLogger(this.getClass());
	
	/*
	 * (non-Javadoc)
	 * @see org.springframework.security.AuthenticationManager#authenticate(org.springframework.security.Authentication)
	 */
	@Override
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {
		// TODO Auto-generated method stub
		if (authentication == null)
			log.info("Cookie not found for remember me authentication service.");
		
		//The token is authentication already, return the token directly
		return authentication;
	}

}
