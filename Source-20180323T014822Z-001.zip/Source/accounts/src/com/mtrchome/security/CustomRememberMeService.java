package com.mtrchome.security;

import java.util.Arrays;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.jasypt.util.text.BasicTextEncryptor;
import org.springframework.security.Authentication;
import org.springframework.security.ui.rememberme.InvalidCookieException;
import org.springframework.security.ui.rememberme.RememberMeServices;
import org.springframework.security.ui.rememberme.TokenBasedRememberMeServices;
import org.springframework.security.userdetails.UserDetails;
import org.springframework.util.StringUtils;

import com.mtrchome.accmgm.util.Constants;


import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This class is used for generating and validating the user session cookie for 'Remember Me' service
 * @author Alvin Chan
 */
public class CustomRememberMeService extends TokenBasedRememberMeServices{

	/**
	 * For logging information
	 */
	private final org.apache.log4j.Logger logger = Logger.getLogger(this.getClass());

	/**
	 * The final string "SPRING_SECURITY_REMEMBER_ME_COOKIE"
	 */
	public static final String SPRING_SECURITY_REMEMBER_ME_COOKIE_KEY = "SPRING_SECURITY_REMEMBER_ME_COOKIE";
	/**
	 * The string SPRING_SECURITY_REMEMBER_ME_COOKIE_KEY = "SPRING_SECURITY_REMEMBER_ME_COOKIE"
	 */
	private String cookieName = SPRING_SECURITY_REMEMBER_ME_COOKIE_KEY;
	
	/**
	 * Default constructor
	 */
	public CustomRememberMeService()
	{	}
	
	/**
	 * Check and validate the session cookie, if the cookie is found and valid, return the UserDetails object
	 */
	@Override
	public UserDetails processAutoLoginCookie(String[] cookieTokens, HttpServletRequest request,
            HttpServletResponse response) {
        if (cookieTokens.length != 3) {
            throw new InvalidCookieException("Cookie token did not contain " + 2 +
                    " tokens, but contained '" + Arrays.asList(cookieTokens) + "'");
        }

        long tokenExpiryTime;

        try {
            tokenExpiryTime = new Long(cookieTokens[1]).longValue();
        }
        catch (NumberFormatException nfe) {
            throw new InvalidCookieException("Cookie token[1] did not contain a valid number (contained '" +
                    cookieTokens[1] + "')");
        }

        if (tokenExpiryTime != -1 && isTokenExpired(tokenExpiryTime)) {
            throw new InvalidCookieException("Cookie token[1] has expired (expired on '"
                    + new Date(tokenExpiryTime) + "'; current time is '" + new Date() + "')");
        }

        // Check the user exists.
        // Defer lookup until after expiry time checked, to possibly avoid expensive database call.

        UserDetails userDetails = getUserDetailsService().loadUserByUsername(cookieTokens[0]);

        // Check signature of token matches remaining details.
        // Must do this after user lookup, as we need the DAO-derived password.
        // If efficiency was a major issue, just add in a UserCache implementation,
        // but recall that this method is usually only called once per HttpSession - if the token is valid,
        // it will cause SecurityContextHolder population, whilst if invalid, will cause the cookie to be cancelled.
        if (!compareSignature(cookieTokens[2], userDetails.getUsername(), userDetails.getPassword(), String.valueOf(tokenExpiryTime)))
        	throw new InvalidCookieException("Cookie signature is not matched.");

        /*
        String expectedTokenSignature = makeMyTokenSignature(tokenExpiryTime, userDetails.getUsername(),
                userDetails.getPassword());
      
        if (!expectedTokenSignature.equals(cookieTokens[2])) {
            throw new InvalidCookieException("Cookie token[2] contained signature '" + cookieTokens[2]
                    + "' but expected '" + expectedTokenSignature + "'");
        }
        */
        
      //create a user session as well
		request.getSession().setAttribute(com.mtrchome.accmgm.util.Constants.USER_SESSION_NAME, userDetails);

        return userDetails;
	}

	/**
	 * Call createToken when the login is success
	 */
	public void onLoginSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication successfulAuthentication) {
        	createToken(request, response, successfulAuthentication);

	}//extends TokenBasedRememberMeServices{
	
	/**
	 * Create a cookie with the combination of username, expiryTime and a signature value
	 * @param request The HttpServletRequest object
	 * @param response The HttpServletResponse object
	 * @param successfulAuthentication The Authentication object
	 */
	public void createToken(HttpServletRequest request, HttpServletResponse response,
			Authentication successfulAuthentication) {
		String username = retrieveUserName(successfulAuthentication);
		String password = retrievePassword(successfulAuthentication);

		// If unable to find a username and password, just abort as TokenBasedRememberMeServices is
        // unable to construct a valid token in this case.
		if (!StringUtils.hasLength(username) || !StringUtils.hasLength(password)) {
			return;
		}
		
		long expiryTime = -1;
		int tokenLifetime = -1;
		
        String paramValue = request.getParameter(getParameter());
        //if remember me is selected by user
        if (paramValue != null) {
            if (paramValue.equalsIgnoreCase("true") || paramValue.equalsIgnoreCase("on") ||
                    paramValue.equalsIgnoreCase("yes") || paramValue.equals("1")) {
            	tokenLifetime = calculateLoginLifetime(request, successfulAuthentication);
            	expiryTime = System.currentTimeMillis() + 1000L*tokenLifetime;
            }
        }

        String signatureValue = makeMyTokenSignature(expiryTime, username, password);

        setMyCookie(new String[] {username, Long.toString(expiryTime), signatureValue}, tokenLifetime, request, response);

		if (logger.isDebugEnabled()) {
			logger.debug("Added remember-me cookie for user '" + username + "', expiry: '"
                    + new Date(expiryTime) + "'");
		}
		
		//create a user session as well
		request.getSession().setAttribute(com.mtrchome.accmgm.util.Constants.USER_SESSION_NAME, (UserDetails) successfulAuthentication.getPrincipal());
		
	}

    /**
     * To set the cookie
     * @param tokens the tokens
     * @param maxAge the maximum age of cookie
     * @param request Java Servlet Http HttpServletRequest
     * @param response Java Servlet Http HttpServletResponse
     */
    protected void setMyCookie(String[] tokens, int maxAge, HttpServletRequest request, HttpServletResponse response) {
        String cookieValue = encodeCookie(tokens);
        Cookie cookie = new Cookie(cookieName, cookieValue);
        if (maxAge != -1)
        	cookie.setMaxAge(maxAge);
        cookie.setPath("/");
        response.addCookie(cookie);
    }
    
	/**
	 * To make the user token signature
	 * @param tokenExpiryTime the token expire time
	 * @param username the user name
	 * @param password the user password
	 * @return The token string
	 */
	protected String makeMyTokenSignature(long tokenExpiryTime,
			String username, String password) {
	//	return DigestUtils.md5Hex(username + ":" + tokenExpiryTime + ":"
	//			+ password + ":" + "springsecurity");
		BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
		textEncryptor.setPassword(Constants.APPLICATION_ENCRYPT_KEY);
		
		String expiryStr = String.valueOf(tokenExpiryTime);
		
		// Error fixed
		//String plainText = username + ":" + expiryStr + ":" + password + ":" + "springsecurity";
		String plainText = username + ":" + expiryStr + ":" + "springsecurity";
		String myEncryptedText = textEncryptor.encrypt(plainText);
		return myEncryptedText;
	}
	
	/**
	 * To compare the signature
	 * @param signature the signature string
	 * @param name the user name
	 * @param password the user password
	 * @param expiryStr the expire time string
	 * @return A flag indicate if the signature match
	 */
	protected boolean compareSignature(String signature, String name, String password, String expiryStr){
		BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
		textEncryptor.setPassword(Constants.APPLICATION_ENCRYPT_KEY);
		
		String plainText = textEncryptor.decrypt(signature);
		// Error fixed
		//String oriText = name + ":" + expiryStr + ":" + password + ":" + "springsecurity";
		String oriText = name + ":" + expiryStr + ":" + "springsecurity";
		
		if (plainText.equals(oriText))
			return true;
		else return false;
		
	}

}
