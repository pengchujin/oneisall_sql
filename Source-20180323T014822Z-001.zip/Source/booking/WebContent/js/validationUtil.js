
function isDigit(parm) {
  val = '0123456789';
  if (parm == "")
    return false;
  for (i=0; i<parm.length; i++) {
    if (val.indexOf(parm.charAt(i),0) == -1)
      return false;
  }
  return true;
}

function isEmpty( inputStr ) { 
	if ( null == inputStr || "" == inputStr ) 
	{ 
		return true; 
	} 
	return false; 
}