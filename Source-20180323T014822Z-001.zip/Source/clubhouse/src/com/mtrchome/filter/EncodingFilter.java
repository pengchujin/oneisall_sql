package com.mtrchome.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

/**
 * Servlet Filter to cater different language submission
 * @author Jacky Ko
 *
 */
public class EncodingFilter implements Filter {

	/**
	 * The encoding
	 */
	protected String encoding = null;
	/**
	 * The filter configuration
	 */
	protected FilterConfig filterConfig = null;

	// protected boolean ignore = true;

	/**
	 * Destroy Filter
	 */
	public void destroy() {
		this.encoding = null;
		this.filterConfig = null;
	}

	/**
	 * Custom Reqest Wrapper
	 * @author joelyen
	 *
	 */
	class Request extends HttpServletRequestWrapper {

		public Request(HttpServletRequest request) {
			super(request);
		}
		
		/**
		 * Method to translate input to target encoding
		 * @param input the input string
		 * @return Encoded string
		 */
		public String toChi(String input) {
			try {

				byte[] bytes = input.getBytes("ISO-8859-1");
				return new String(bytes, encoding);
			} catch (Exception ex) {
			}
			return null;
		}

		/**
		 * Return the HttpServletRequest holded by this object.
		 */
		private HttpServletRequest getHttpServletRequest() {
			return (HttpServletRequest) super.getRequest();
		}

		/**
		 * Get input parameter key
		 */
		public String getParameter(String name) {
			return toChi(getHttpServletRequest().getParameter(name));
		}

		
		/**
		 * Get input parameter value
		 */
		public String[] getParameterValues(String name) {
			String values[] = getHttpServletRequest().getParameterValues(name);
			if (values != null) {
				for (int i = 0; i < values.length; i++) {
					values[i] = toChi(values[i]);
				}
			}
			return values;
		}
	}

	/**
	 * Execute filter main logic
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		response.setCharacterEncoding("UTF-8");

		// if (ignore || (request.getCharacterEncoding() == null)) {
		// String encoding = selectEncoding(request);
		/*
		 * if (encoding != null) request.setCharacterEncoding(encoding);
		 */
		// }
		HttpServletRequest httpreq = (HttpServletRequest) request;
		if (httpreq.getMethod().equals("POST")) {
			request.setCharacterEncoding(encoding);
		} else {
			request = new Request(httpreq);
		}

		// Pass control on to the next filter
		chain.doFilter(request, response);

	}

	/**
	 * Place this filter into service.
	 * 
	 * @param filterConfig The filter configuration object
	 */
	public void init(FilterConfig filterConfig) throws ServletException {

		this.filterConfig = filterConfig;
		this.encoding = filterConfig.getInitParameter("encoding");

	}

}
