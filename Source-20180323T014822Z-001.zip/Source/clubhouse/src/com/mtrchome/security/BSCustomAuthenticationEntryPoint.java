package com.mtrchome.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;
import org.springframework.security.AuthenticationException;
import org.springframework.security.ui.webapp.AuthenticationProcessingFilterEntryPoint;

/**
 * This class is the custom authentication entry point of the authentication processing filter. 
 * This is for Facility Booking System.
 * @author Alvin Chan
 */
public class BSCustomAuthenticationEntryPoint extends
		AuthenticationProcessingFilterEntryPoint {

	/**
	 * For logging information
	 */
	private final org.apache.log4j.Logger log = Logger.getLogger(this
			.getClass());
	/**
	 * HTTP Session key
	 */
	private String sessionKey = null;

	/**
	 * To get the sessionKey
	 * @return sessionKey This object's session key
	 */
	public String getSessionKey() {
		return sessionKey;
	}

	/**
	 * To set the sessionkey
	 * @param sessionKey This object's session key
	 */
	public void setSessionKey(String sessionKey) {
		this.sessionKey = sessionKey;
	}

	/**
	 * To get the logger
	 * @return log This object's logger
	 */
	public org.apache.log4j.Logger getLog() {
		return log;
	}

	@Override
	public void commence(ServletRequest request, ServletResponse response,
			AuthenticationException authException) throws IOException,
			ServletException {

		log.info("commence started.");
		/*
		 * Cookie[] cookies = ((HttpServletRequest)request).getCookies(); int
		 * i=0; boolean found=false; if (cookies != null) { // int len =
		 * cookies.length; for (i=0;i<cookies.length;i++) { //
		 * @SuppressWarnings("unused") // String name = cookies[i].getName(); if
		 * (cookies[i].getName().equals("mtrctoken")) { found = true; break; } }
		 * }
		 * 
		 * if (found) { BasicTextEncryptor textEncryptor = new
		 * BasicTextEncryptor(); textEncryptor.setPassword(this.sessionKey);
		 * String myEncryptedText = cookies[i].getValue(); String plainText =
		 * textEncryptor.decrypt(myEncryptedText); String loginName = ""; String
		 * password = ""; try{ loginName = plainText.split("@@")[0]; password =
		 * plainText.split("@@")[1]; }catch(Exception e) {
		 * log.error("Invalid format of the token"); }
		 * 
		 * String url = null; try { url = new String(
		 * ("j_spring_security_check?j_username="
		 * +java.net.URLEncoder.encode(loginName, "UTF-8")
		 * +"&j_password="+password).getBytes("UTF-8"),"ISO8859_1"); } catch
		 * (UnsupportedEncodingException e) { // TODO Auto-generated catch block
		 * log.error("Login action forwarding error: " + e.getMessage());
		 * e.printStackTrace(); }
		 * 
		 * HttpServletResponse hresponse = (HttpServletResponse)response; try {
		 * hresponse.sendRedirect(url); } catch (IOException e) { // TODO
		 * Auto-generated catch block
		 * log.error("Login action response redirect error: " + e.getMessage());
		 * e.printStackTrace(); }
		 * 
		 * } else
		 */
		super.commence(request, response, authException);

	}

}