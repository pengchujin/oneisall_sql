package com.mtrchome.security;

import java.io.IOException;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.Authentication;
import org.springframework.security.ui.webapp.AuthenticationProcessingFilter;

import com.mtrchome.accmgm.model.enums.UserLanguage;

/**
 * A custom authentication filter for the Authentication Processing Filter, this class mainly handle the logic after user is login successfully. 
 * This is for Facility Booking System.
 * @author Alvin Chan
 */
public class BSCustomAuthenticationFilter extends AuthenticationProcessingFilter {

	/**
	 * HTTP Session key
	 */
	private String sessionKey = null;
	
	/**
	 * To get the sessionKey
	 * @return sessionKey This object's session key
	 */
	public String getSessionKey() {
		return sessionKey;
	}

	/**
	 * To set the sessionkey
	 * @param sessionKey This object's session key
	 */
	public void setSessionKey(String sessionKey) {
		this.sessionKey = sessionKey;
	}

	@Override
	protected void onSuccessfulAuthentication(HttpServletRequest request,
			HttpServletResponse response, Authentication authResult)
			throws IOException {
		
		super.onSuccessfulAuthentication(request, response, authResult);
		
/*		request.getSession().setAttribute(com.mtrchome.accmgm.util.Constants.USER_SESSION_NAME, authResult.getName());

		//StrongPasswordEncryptor passwordEncryptor = new StrongPasswordEncryptor();
		//String encryptedPassword = passwordEncryptor.encryptPassword("test");
		BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
		textEncryptor.setPassword(this.sessionKey);
		String userPwd = (String)authResult.getCredentials();
		String myText = authResult.getName() + "@@" + userPwd;
		String myEncryptedText = textEncryptor.encrypt(myText);
		
		Cookie cookie = new Cookie(com.mtrchome.accmgm.util.Constants.SSO_COOKIE_TOKEN, myEncryptedText);
		cookie.setPath("/");
		response.addCookie(cookie);*/
		BSCustomRememberMeService remService = new BSCustomRememberMeService();
		remService.createToken(request, response, authResult);
		
		//set locale
		SecurityUser user = (SecurityUser) request.getSession().getAttribute(com.mtrchome.accmgm.util.Constants.USER_SESSION_NAME);
		long lang = user.getDBUser().getMtrchomeUserProfile().getPreferredLanguageId();
		int langId = Integer.parseInt(String.valueOf(lang));
		  if (langId == UserLanguage.English.language())
			  response.setLocale(Locale.ENGLISH);
		  else if (langId == UserLanguage.Traditional_Chinese.language())
			  response.setLocale(Locale.CHINESE);  
		  else if (langId == UserLanguage.Simplified_Chinese.language())
			  response.setLocale(Locale.SIMPLIFIED_CHINESE);
		
	}
}