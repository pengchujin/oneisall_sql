package com.mtrchome.security;

import org.apache.log4j.Logger;
import org.springframework.security.Authentication;
import org.springframework.security.AuthenticationException;
import org.springframework.security.AuthenticationManager;

/**
 * A custom authentication manager for the 'Remember Me' service. This is for Facility Booking System.
 * @author Alvin Chan
 */
public class BSCustomRememberMeAuthenMgr implements AuthenticationManager {

	/**
	 * For logging information
	 */
	private final org.apache.log4j.Logger log = Logger.getLogger(this
			.getClass());

//	@Override
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {
		log.debug("authenticate(Authentication authentication) called...");

		if (authentication == null)
			log.info("Cookie not found for remember me authentication service.");

		// The token is authentication already, return the token directly
		return authentication;
	}

}
