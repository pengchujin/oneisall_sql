package com.mtrchome.security;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger; //import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.Authentication;
import org.springframework.security.AuthenticationException; //import org.springframework.security.AuthenticationManager;
import org.springframework.security.BadCredentialsException;
import org.springframework.security.providers.AuthenticationProvider;
import org.springframework.security.providers.UsernamePasswordAuthenticationToken;

import com.mtrchome.accmgm.dao.MtrchomeUserDAO;

/**
 * A custom authentication provider, the authenticate() method in this class is the major function for user authentication
 * @author Alvin Chan
 */
public class CustomAuthenticationProvider implements AuthenticationProvider { 

	/**
	 * MtrchomeUserDAO contains methods for data maintenance of users
	 */
	// @Autowired
	MtrchomeUserDAO userDAO = null; // new MtrchomeUserDAOImpl();

	/**
	 * For logging information
	 */
	private final org.apache.log4j.Logger log = Logger.getLogger(this
			.getClass());

	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {
		log.debug("Start authen");
		if (StringUtils.isBlank((String) authentication.getPrincipal())
				|| StringUtils
						.isBlank((String) authentication.getCredentials())) {
			throw new BadCredentialsException("Invalid username/password");
		}

		SecurityUser user = null;

		try {
			user = (SecurityUser) userDAO
					.loadUserByUsername((String) authentication.getPrincipal());
		} catch (Exception e) {
			log.debug("user object not found.");
			// throw new
			// AuthenticationServiceException("Authentication failed.");
		}

		// user found, validate the password
		String pwd = (String) authentication.getCredentials();

		if (pwd.equals((String) authentication.getCredentials()))
			return new UsernamePasswordAuthenticationToken(authentication
					.getPrincipal(), authentication.getCredentials(), user
					.getAuthorities());
		else
			return null;

	}

	/**
	 * To set the field userDAO
	 * @param userDAO the userDAO to set
	 */
	public void setUserDAO(MtrchomeUserDAO userDAO) {
		this.userDAO = userDAO;
	}

	@SuppressWarnings("unchecked")
//	@Override
	public boolean supports(Class arg0) {

		String name = arg0.getName();
		log.debug("The support class name is: " + name);
		return true;
	}
}