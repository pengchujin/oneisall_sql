package com.mtrchome.security;

import org.springframework.security.GrantedAuthority;
import org.springframework.security.GrantedAuthorityImpl;
import org.springframework.security.userdetails.UserDetails;

import com.mtrchome.accmgm.model.MtrchomeUser;
import com.mtrchome.accmgm.model.hashmap.UserTypeMap;

/**
 * This is the user object used in Spring Security
 * It implements the UserDetails class and contains the MtrchomeUser object and a list of granted authority - GrantedAuthority[]
 * @author Alvin Chan
 */
@SuppressWarnings("serial")
public class SecurityUser implements UserDetails{
	/**
	 * The user
	 */
	private MtrchomeUser user;
	/**
	 * The list of authority
	 */
	private GrantedAuthority[] authorityList;
	
	/**
	 * Constructor
	 * @param user the user
	 */
	public SecurityUser(MtrchomeUser user)
	{
		this.user = user;
	}
	
	/**
	 * To set the user
	 * @param user the user to set
	 */
	public void setDBUser(MtrchomeUser user) {
		// TODO Auto-generated method stub
		this.user = user;
	}
	
	/**
	 * To get the user
	 * @return the user to get
	 */
	public MtrchomeUser getDBUser(){
		return this.user;
	}
	
	
//	@Override
	public GrantedAuthority[] getAuthorities() {
		// TODO Auto-generated method stub
		Long userType = this.user.getUserTypeId();
		int userTypeId = Integer.parseInt(String.valueOf(userType));
	    
		String role = UserTypeMap.getUserRole(userTypeId);
		GrantedAuthority authority = new GrantedAuthorityImpl(role);
		authorityList = new GrantedAuthority[1];
		authorityList[0] = authority;
		
		return authorityList;
	}

//	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return this.user.getPassword();
	}

//	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return this.user.getLoginName();
	}

//	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

//	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

//	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

//	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

}
